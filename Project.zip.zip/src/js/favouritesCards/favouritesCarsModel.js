export default class FavouritesCards {
    constructor(favsList) {
        this.favsList = favsList;

    }

    //Получаем данные с сервера
    async getFavs() {
        const ids = this.favsList.toString(); //1,3,5
        const queryString = `http://jsproject.webcademy.ru/items?ids=${ids}`;
        const result = await fetch(queryString);
        const data = await result.json();
        this.cards = await data;
    }

}